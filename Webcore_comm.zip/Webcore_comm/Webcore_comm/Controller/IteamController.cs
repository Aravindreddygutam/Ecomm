﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Webcore_comm.Data;
using Webcore_comm.Data.Models;
using Webcore_comm.Data.Interfaces;
using Webcore_comm.ViewModels;

namespace Webcore_comm.Controllers
{
    public class IteamController : Controller
    {
       public readonly IIteamsRespository _iteamsRespository;
        public readonly ICategoryRepository _categoryRepository;

        public IteamController(ICategoryRepository categoryRepository, IIteamsRespository iteamsRespository)
        {
            _categoryRepository = categoryRepository;
            _iteamsRespository = iteamsRespository;

        }

        public ViewResult List()



        {
            ViewBag.Name = "Iteams";
           
             var iteams = _iteamsRespository.Iteamss;
            IteamListViewModel vm = new IteamListViewModel();
           
            vm.Iteamss= _iteamsRespository.Iteamss;
            vm.CurrentCategory = "current iteams";
            return View(vm);
        }
        //public IActionResult Index()
        //{
        //    return View();
        //}
    }
}