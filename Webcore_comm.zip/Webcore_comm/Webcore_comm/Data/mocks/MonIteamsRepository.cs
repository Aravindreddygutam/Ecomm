﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Webcore_comm.Data.Interfaces;
using Webcore_comm.Data.Models;

namespace Webcore_comm.Data.mocks
{
    public class MonIteamsRepository : IIteamsRespository
    {
        private readonly ICategoryRepository _IteamsRespository = new MonCategoryRepository();
        public IEnumerable<Iteams> Iteamss
        {
            get =>
new List<Iteams> { new Iteams { IName = "earphone", Iprice = "100", Category = _IteamsRespository.Categories.First() }, new Iteams { IName = "dress", Iprice = "200", Category = _IteamsRespository.Categories.First() } };
            set => throw new NotImplementedException();
        }
        public IEnumerable<Iteams> PreferredIteamss { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public Iteams GetIteamsId(int IteamsId)
        {
            throw new NotImplementedException();
        }
    }
}
