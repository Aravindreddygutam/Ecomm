﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Webcore_comm.Data.Interfaces;
using Webcore_comm.Data.Models;

namespace Webcore_comm.Data.mocks
{
    public class MonCategoryRepository : ICategoryRepository
    {
        public IEnumerable<Category> Categories { get => new List<Category> { new Category { Categoryname="fas",Description="dre" }, new Category { Categoryname = "ela", Description = "moible" } }; set => throw new NotImplementedException(); }
    }
}
