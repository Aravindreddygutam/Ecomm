﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Webcore_comm.Data.Models;

namespace Webcore_comm.Data.Repositories
{
    public class IteamRepository : IIteamsRespository
    {
        private readonly AppDbContext _appDbContext;
        public IteamRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }
         public IEnumerable<Iteams> Iteamss { get => _appDbContext.iteamss.Include(c => c.Category); set => throw new NotImplementedException(); }

        // public IEnumerable<Iteams> Iteamss { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public IEnumerable<Iteams> PreferredIteamss { get => _appDbContext.iteamss.Where(p => p.IsPreferrediteam).Include(c => c.Category); set => throw new NotImplementedException(); }

        public Iteams GetIteamsId(int IteamsId)=> _appDbContext.iteamss.FirstOrDefault(p=>p.IteamsId== IteamsId);
        
    }
}
