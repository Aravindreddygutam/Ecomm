﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Webcore_comm.Data.Models;

namespace Webcore_comm.Data
{
   public interface IIteamsRespository
    {
        IEnumerable<Iteams> Iteamss { get; set; }
        IEnumerable<Iteams> PreferredIteamss { get; set; }
        Iteams GetIteamsId(int IteamsId);
    }
}
