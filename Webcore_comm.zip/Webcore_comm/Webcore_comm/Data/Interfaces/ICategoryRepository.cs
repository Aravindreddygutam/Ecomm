﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Webcore_comm.Data.Models;

namespace Webcore_comm.Data.Interfaces
{
   public interface ICategoryRepository
    {
        IEnumerable<Category> Categories { get; set; }
    }
}
