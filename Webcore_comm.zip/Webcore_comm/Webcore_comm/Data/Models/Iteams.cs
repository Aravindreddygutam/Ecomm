﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Webcore_comm.Data.Models
{
    public class Iteams
    {
        public  int IteamsId  { get; set; }
        public  string IName { get; set; }
        public string  Iprice { get; set; }
        public bool IsPreferrediteam { get; set; }

        public int CategoryID { get; set; }
        public virtual Category Category  { get; set; }

    }
}
