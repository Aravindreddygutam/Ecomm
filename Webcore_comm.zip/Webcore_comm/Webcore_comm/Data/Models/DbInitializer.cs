﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Webcore_comm.Data.Models;

namespace Webcore_comm.Data.Dbinitializer
{
    public class DbInitializer
    {
        public static void Seed(IApplicationBuilder applicationBuilder)
        {
            AppDbContext context = applicationBuilder.ApplicationServices.GetRequiredService<AppDbContext>();
            //AppDbContext context =
            //    applicationBuilder.ApplicationServices.GetRequiredService<AppDbContext>();

            if (!context.categories.Any())
            {
                context.categories.AddRange(categories.Select(c => c.Value));
            }

            if (!context.iteamss.Any())
            {
                context.AddRange
                (
                    new Iteams
                    {
                        
                        IName="mobile",
                        Iprice="2000,",
                        IsPreferrediteam=true,
                        Category= categories["ela"]

                    },
                    new Iteams
                    {

                        IName = "ear",
                        Iprice = "100,",
                        IsPreferrediteam = false,
                        Category = categories["ela"]
                    },
                    new Iteams
                    {

                        IName = "dress",
                        Iprice = "100,",
                        IsPreferrediteam = true,
                        Category = categories["fasion"]
                    }

                );
            }

            context.SaveChanges();
        }

        private static Dictionary<string, Category> categories;
        public static Dictionary<string, Category> Categories
        {
            get
            {
                if (categories == null)
                {
                    var genresList = new Category[]
                    {
                        new Category { Categoryname = "ela", Description="All ela" },
                        new Category { Categoryname = "fasion", Description="All dress" }
                    };

                    categories = new Dictionary<string, Category>();

                    foreach (Category genre in genresList)
                    {
                        categories.Add(genre.Categoryname, genre);
                    }
                }

                return categories;
            }
        }
    }
}
