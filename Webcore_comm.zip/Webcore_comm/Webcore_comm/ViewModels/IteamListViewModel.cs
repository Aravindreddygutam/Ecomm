﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Webcore_comm.Data.Models;

namespace Webcore_comm.ViewModels
{
    public class IteamListViewModel
    {
        public IEnumerable<Iteams> Iteamss{ get; set; }
        public string CurrentCategory { get; set; }

    }
}
